package com.arcadio.triplover.models.search.request;

public class Search {
}
