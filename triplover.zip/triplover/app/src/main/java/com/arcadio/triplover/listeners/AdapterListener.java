package com.arcadio.triplover.listeners;

public interface AdapterListener {
    void onClickItem(int pos, int viewId);
}
