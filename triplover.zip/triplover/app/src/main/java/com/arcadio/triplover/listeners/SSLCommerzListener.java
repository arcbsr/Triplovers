package com.arcadio.triplover.listeners;

public interface SSLCommerzListener {
}
