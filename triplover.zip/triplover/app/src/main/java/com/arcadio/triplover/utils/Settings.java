package com.arcadio.triplover.utils;

public class Settings {

}
